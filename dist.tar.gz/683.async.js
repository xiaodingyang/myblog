"use strict";(self.webpackChunkblog_frontend=self.webpackChunkblog_frontend||[]).push([[683],{24683:function(m,g,o){o.r(g);var I=o(92379),l=o(1104),v=o(89569),h=o(85124),s=o(651),D=["wave","wave2d","tyndall"],i=function(t,n){var a=t.replace("#",""),u=Math.round(parseInt(a.substring(0,2),16)*n),r=Math.round(parseInt(a.substring(2,4),16)*n),e=Math.round(parseInt(a.substring(4,6),16)*n);return{r:u,g:r,b:e}},b=function(t){var n=t.replace("#",""),a=parseInt(n.substring(0,2),16),u=parseInt(n.substring(2,4),16),r=parseInt(n.substring(4,6),16),e=i(t,.12),d=i(t,.08),c=i(t,.18);return`
    /* \u4E3B\u9898\u8272\u5149\u6655 - \u5DE6\u4E0A\u89D2 */
    radial-gradient(ellipse 45% 50% at 5% 5%, rgba(`.concat(a,", ").concat(u,", ").concat(r,`, 0.35) 0%, transparent 60%),
    /* \u4E3B\u9898\u8272\u5149\u6655 - \u53F3\u4E0B\u89D2 */
    radial-gradient(ellipse 55% 60% at 95% 95%, rgba(`).concat(a,", ").concat(u,", ").concat(r,`, 0.25) 0%, transparent 55%),
    /* \u4E2D\u95F4\u67D4\u548C\u5149\u6655 */
    radial-gradient(ellipse 40% 35% at 80% 30%, rgba(`).concat(a,", ").concat(u,", ").concat(r,`, 0.12) 0%, transparent 60%),
    /* \u6DF1\u8272\u4E3B\u9898\u8272\u6E10\u53D8\u80CC\u666F */
    linear-gradient(
      135deg,
      rgba(`).concat(e.r,", ").concat(e.g,", ").concat(e.b,`, 0.88) 0%,
      rgba(`).concat(d.r,", ").concat(d.g,", ").concat(d.b,`, 0.85) 35%,
      rgba(`).concat(c.r,", ").concat(c.g,", ").concat(c.b,`, 0.82) 65%,
      rgba(`).concat(e.r,", ").concat(e.g,", ").concat(e.b,`, 0.90) 100%
    )
  `)},k=function(t){var n=t.isDark,a=n===void 0?!0:n,u=(0,v.useModel)("particleModel"),r=u.themeId,e=(0,v.useModel)("colorModel"),d=e.themeId,c=(0,h.Be)(d).primary,M=D.includes(r),_=b(c);return r==="tyndall"?(0,s.jsx)(l._d,{theme:r,isDark:a,themeColor:c}):M?(0,s.jsx)(l._d,{theme:r,isDark:a,themeColor:c,style:{background:_}}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("div",{style:{position:"fixed",inset:0,zIndex:0,pointerEvents:"none",background:_}}),(0,s.jsx)(l._d,{theme:r,isDark:a,themeColor:void 0})]})};g.default=k}}]);
